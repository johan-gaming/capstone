import React,{useState,useEffect} from 'react';
import './DonorDashboard.css';

const DonorDashboard = () => {
  const [donations,setDonations] = useState([]);
  const [loading,setLoading] = useState(true);
  const [showModal,setShowModal] = useState(false);
  const [donorName,setDonorName] = useState('Donor');

  // Fetch donations (for this donor)
  const fetchDonations = async() => {
    try {
      const response = await fetch('http://localhost:5000/api/donations');
      const data = await response.json();

      // Filter only this donor’s donations
      const donorData = data.filter(d => d.donorName === donorName);
      setDonations(donorData);
    } catch(err){
      console.error('Error fetching donations:',err);
      alert('Failed to load donations.');
    } finally {
      setLoading(false);
    }
  };

  // Post a new donation
  const addDonation = async(item,quantity) => {
    try {
      await fetch('http://localhost:5000/api/donations', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          donorName,
          item,
          quantity,
          status: 'Pending'
        })
      });
      fetchDonations();
    } catch(err){
      console.error('Error adding donation:',err);
    }
  };

  useEffect(()=>{
    fetchDonations();
  },[donorName]);

  return (
    <div className="dashboard-container fade-in">
      <h1 className="dashboard-header">Welcome, {donorName}</h1>

      <div className="summary-card">
        <p>
          Total Donations Made: <strong>{donations.length}</strong>
        </p>
      </div>

      <button className="donation-button" onClick={()=>setShowModal(true)}>
        Post New Donation
      </button>

      <div className="donation-history">
        <h2>Recent Donations</h2>
        <table className="donation-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Food Item</th>
              <th>Quantity</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="4">Loading...</td>
              </tr>
            ) : donations.length>0 ? (
              donations.map((donation)=>(
                <tr key={donation.id}>
                  <td>{donation.id}</td>
                  <td>{donation.item}</td>
                  <td>{donation.quantity}</td>
                  <td>{donation.status}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="4">No donations yet.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {showModal && (
        <div className="modal-backdrop">
          <div className="modal-box fade-in">
            <DonationForm
              onClose={()=>setShowModal(false)}
              onSubmit={(item,quantity)=>{
                addDonation(item,quantity);
                setShowModal(false);
              }}
            />
          </div>
        </div>
      )}
    </div>
  );
};

// Simple inline form (instead of Firebase form)
const DonationForm = ({onClose,onSubmit}) => {
  const [item,setItem] = useState('');
  const [quantity,setQuantity] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if(item && quantity){
      onSubmit(item,quantity);
    }
  };

  return (
    <form className="donor-form" onSubmit={handleSubmit}>
      <h2>Post New Donation</h2>
      <label>Food Item</label>
      <input value={item} onChange={(e)=>setItem(e.target.value)} required />
      <label>Quantity</label>
      <input value={quantity} onChange={(e)=>setQuantity(e.target.value)} required />
      <div className="form-actions">
        <button type="submit">Submit</button>
        <button type="button" onClick={onClose}>Cancel</button>
      </div>
    </form>
  );
};

export default DonorDashboard;
