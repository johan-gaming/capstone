import React,{useState,useEffect} from 'react';
import './NGODashboard.css';

const NGODashboard = () => {
  const [donations,setDonations] = useState([]);
  const [loading,setLoading] = useState(true);

  // Fetch donations from backend
  const fetchDonations = async() => {
    try {
      const response = await fetch('http://localhost:5000/donations'); // ✅ corrected path
      const data = await response.json();
      setDonations(data);
    } catch(err){
      console.error('Error fetching donations:',err);
      alert('Failed to load donations.');
    } finally {
      setLoading(false);
    }
  };

  // Claim a donation
  const claimDonation = async(id) => {
    try {
      await fetch(`http://localhost:5000/donations/${id}`, { // ✅ corrected path
        method: 'PUT',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({status: 'Claimed'})
      });
      fetchDonations(); // refresh list
    } catch(err){
      console.error('Error claiming donation:',err);
    }
  };

  useEffect(()=>{
    fetchDonations();
  },[]);

  return (
    <div className="dashboard-container fade-in">
      <h1 className="dashboard-header">NGO Dashboard</h1>

      <div className="donation-history">
        <h2>Available Donations</h2>
        <table className="donation-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Donor</th>
              <th>Item</th>
              <th>Quantity</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan="6">Loading...</td>
              </tr>
            ) : donations.length>0 ? (
              donations.map((donation)=>(
                <tr key={donation.id}>
                  <td>{donation.id}</td>
                  <td>{donation.donorName || 'Anonymous'}</td>
                  <td>{donation.item}</td>
                  <td>{donation.quantity}</td>
                  <td>{donation.status}</td>
                  <td>
                    {donation.status === 'Available' ? ( // ✅ match backend default
                      <button onClick={()=>claimDonation(donation.id)}>
                        Claim
                      </button>
                    ) : (
                      'Already Claimed'
                    )}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="6">No donations yet.</td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default NGODashboard;
